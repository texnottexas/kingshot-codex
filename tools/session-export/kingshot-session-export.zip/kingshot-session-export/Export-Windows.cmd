@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Export-Windows.ps1" %*
pause
