#!/usr/bin/env python3
"""Export only Kingshot FPID/session_key from one stopped, locally selected instance."""
import argparse
from contextlib import contextmanager
import ctypes
import io
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET

PREF = 'com.run.tower.defense/shared_prefs/com.cg.sdk.xml'
PREF_PATHS = ('/data/' + PREF, '/user/0/' + PREF, '/data/data/' + PREF)
MAX_XML = 2 * 1024 * 1024


class ExportError(Exception):
    """Only static messages, never XML, session values or library exceptions."""


def parse_session(xml):
    if len(xml) > MAX_XML or b'<!DOCTYPE' in xml.upper() or b'<!ENTITY' in xml.upper():
        raise ExportError('Unsupported Kingshot settings file.')
    try:
        root = ET.fromstring(xml)
        if root.tag != 'map':
            raise ValueError()
        values = [e.text for e in root if e.tag == 'string' and e.get('name') == 'account_session']
        if len(values) != 1:
            raise ValueError()
        data = json.loads(values[0])
        fpid, session = data['fpid'], data['session_key']
        if type(fpid) not in (int, str) or not re.fullmatch(r'[0-9]{1,32}', str(fpid)):
            raise ValueError()
        if not isinstance(session, str) or not 1 <= len(session) <= 256 or any(ord(c) < 32 for c in session):
            raise ValueError()
        return {'fpid': str(fpid), 'session_key': session}
    except (ET.ParseError, ValueError, TypeError, KeyError):
        raise ExportError('No usable Kingshot login found. Log in to the intended account, then quit BlueStacks.') from None


def roots():
    if sys.platform == 'darwin':
        return [Path('/Users/Shared/Library/Application Support/BlueStacks')]
    if os.name == 'nt':
        found = [Path(os.environ.get('ProgramData', r'C:\ProgramData')) / 'BlueStacks_nxt']
        import winreg
        for key in (r'SOFTWARE\BlueStacks_nxt', r'SOFTWARE\WOW6432Node\BlueStacks_nxt'):
            try:
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key) as reg:
                    found.append(Path(winreg.QueryValueEx(reg, 'UserDefinedDir')[0]))
            except OSError:
                pass
        return list(dict.fromkeys(found))
    return []


def discover(base):
    config = base / 'bluestacks.conf'
    if not config.is_file():
        return []
    entries = []
    for line in config.read_text(encoding='utf-8-sig', errors='replace').splitlines():
        match = re.fullmatch(r'bst\.instance\.([A-Za-z0-9_-]+)\.display_name="(.*)"', line.strip())
        if not match:
            continue
        ident, name = match.groups()
        folder = base / 'Engine' / ident
        if not folder.is_dir():
            continue
        disks = sorted(p for p in folder.iterdir() if p.name.lower() in ('data.qcow2', 'data.vhdx', 'data.vhd'))
        if len(disks) == 1:
            entries.append({'id': ident, 'name': ''.join(c for c in name if c.isprintable()), 'disk': disks[0]})
    return entries


def mac_not_running(path):
    if sys.platform != 'darwin':
        return
    result = subprocess.run(['/usr/sbin/lsof', '-t', '--', str(path)], capture_output=True, text=True, timeout=15)
    if result.returncode not in (0, 1) or result.stderr.strip():
        raise ExportError('Could not check whether the selected instance is stopped. Quit BlueStacks and try again.')
    if any(value != str(os.getpid()) for value in result.stdout.split()):
        raise ExportError('The selected instance is still running. Stop it in Multi-instance Manager and try again.')


@contextmanager
def source_file(path):
    """Windows denies concurrent opens for the duration; all source access is read-only."""
    if os.name != 'nt':
        mac_not_running(path)
        with path.open('rb') as source:
            yield source
        mac_not_running(path)
        return
    import msvcrt
    from ctypes import wintypes
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                                  ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    kernel.CreateFileW.restype = wintypes.HANDLE
    handle = kernel.CreateFileW(str(path), 0x80000000, 0, None, 3, 0x80, None)
    if handle == ctypes.c_void_p(-1).value:
        raise ExportError('Cannot open the disk exclusively. Stop all BlueStacks instances; check that your Windows account can read the disk.')
    fd = msvcrt.open_osfhandle(handle, os.O_RDONLY | os.O_BINARY)
    with os.fdopen(fd, 'rb') as source:
        class NamedSource:
            name = str(path)
            def __getattr__(self, attr):
                return getattr(source, attr)
        yield NamedSource()


def virtual_disk(source):
    source.seek(0);magic = source.read(8);source.seek(0)
    if magic[:4] == b'QFI\xfb':
        from dissect.hypervisor.disk.qcow2 import QCow2
        return QCow2(source).open()
    if magic == b'vhdxfile':
        from dissect.hypervisor.disk.vhdx import VHDX
        return VHDX(source)
    source.seek(-512, io.SEEK_END);footer = source.read(8);source.seek(0)
    if footer == b'conectix':
        from dissect.hypervisor.disk.vhd import VHD
        return VHD(source)
    raise ExportError('Unsupported virtual disk. Select data.qcow2, Data.vhdx or Data.vhd from the instance folder.')


def ext4_regions(disk):
    """Probe bounded raw/MBR/GPT locations instead of assuming one fixed offset."""
    disk.seek(0, io.SEEK_END);size = disk.tell();regions = [(0, size)]
    disk.seek(0);mbr = disk.read(512)
    if len(mbr) == 512 and mbr[510:512] == b'\x55\xaa':
        for index in range(4):
            part = mbr[446 + index * 16:462 + index * 16]
            start, count = struct.unpack_from('<II', part, 8)
            if part[4] not in (0, 0xee) and start and count:
                regions.append((start * 512, count * 512))
    for sector in (512, 4096):
        disk.seek(sector);header = disk.read(92)
        if header[:8] != b'EFI PART':
            continue
        table, count, entry_size = struct.unpack_from('<QII', header, 72)
        if not 0 < count <= 256 or not 128 <= entry_size <= 4096 or table * sector + count * entry_size > size:
            raise ExportError('Unsupported partition table.')
        disk.seek(table * sector);entries = disk.read(count * entry_size)
        for offset in range(0, len(entries), entry_size):
            entry = entries[offset:offset + entry_size]
            if entry[:16] == b'\0' * 16:
                continue
            first, last = struct.unpack_from('<QQ', entry, 32)
            if first and last >= first:
                regions.append((first * sector, (last - first + 1) * sector))
    valid = []
    for start, length in dict.fromkeys(regions):
        if start < 0 or length < 2048 or start + length > size:
            continue
        disk.seek(start + 1024 + 56)
        if disk.read(2) == b'\x53\xef':
            valid.append((start, length))
    return valid


def extract(path):
    from dissect.extfs import ExtFS
    from dissect.util.stream import RangeStream
    before = path.stat()
    with source_file(path) as source:
        disk = virtual_disk(source)
        matches = []
        for start, length in ext4_regions(disk):
            fs = ExtFS(RangeStream(disk, start, length))
            for pref in PREF_PATHS:
                try:
                    node = fs.get(pref)
                except FileNotFoundError:
                    continue
                xml = node.open().read(MAX_XML + 1)
                value = parse_session(xml)
                if value not in matches:
                    matches.append(value)
        if len(matches) != 1:
            raise ExportError('No single Kingshot login found. Select the correct instance after a fresh login. Encrypted or unfamiliar disk layouts are not supported.')
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ExportError('The disk changed during the read. Stop the instance and try again.')
    return matches[0]


def private_folder(parent):
    if not parent.is_dir():
        raise ExportError('The output parent folder does not exist.')
    folder = Path(tempfile.mkdtemp(prefix='kingshot-login-', dir=parent))
    try:
        if os.name == 'nt':
            # Set ACL before writing credentials, using the current user's SID (no localized group names).
            result = subprocess.run(['whoami', '/user', '/fo', 'csv', '/nh'], capture_output=True, text=True, check=True)
            match = re.search(r'S-1-[0-9-]+', result.stdout)
            if not match:
                raise ExportError('Could not identify your Windows account for private file permissions.')
            result = subprocess.run(['icacls', str(folder), '/inheritance:r', '/grant:r',
                                     '*' + match[0] + ':(OI)(CI)F'], capture_output=True, text=True)
            if result.returncode:
                raise ExportError('Could not restrict the output folder to your Windows account.')
        else:
            folder.chmod(0o700)
        return folder
    except BaseException:
        folder.rmdir()
        raise


def save_session(credentials, parent):
    folder = private_folder(parent)
    target = folder / 'kingshot-session.json'
    try:
        with os.fdopen(os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), 'w') as stream:
            json.dump(credentials, stream, separators=(',', ':'));stream.write('\n')
    except BaseException:
        target.unlink(missing_ok=True);folder.rmdir();raise
    return target


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, help='BlueStacks data folder containing bluestacks.conf')
    parser.add_argument('--disk', type=Path, help='Exact data disk, for custom installations')
    parser.add_argument('--instance', help='Exact instance ID or display name')
    parser.add_argument('--list', action='store_true', help='List instances without reading any login')
    parser.add_argument('--output-dir', type=Path, default=Path.home() / 'Downloads', help='Parent folder for a new private export folder')
    args = parser.parse_args(argv)
    try:
        entries = [e for root in ([args.root] if args.root else roots()) for e in discover(root)]
        if args.list:
            for e in entries:print(f"{e['id']}  |  {e['name']}")
            if not entries:print('No instances found. Use --root with your BlueStacks data folder.')
            return 0
        if args.disk:
            path = args.disk.expanduser().resolve(strict=True)
        else:
            if args.instance:
                entries = [e for e in entries if args.instance in (e['id'], e['name'])]
                if len(entries) != 1:raise ExportError('Instance name is missing or ambiguous. Use --list or --disk.')
                selected = entries[0]
            else:
                if not entries:raise ExportError('No instances found. Use --root or --disk for a custom installation.')
                print('Select the instance with the dummy account you want to export:')
                for index, e in enumerate(entries, 1):print(f"{index}. {e['name']} ({e['id']})")
                value = input('Instance number: ').strip()
                if not value.isdigit() or not 1 <= int(value) <= len(entries):raise ExportError('No valid instance selected.')
                selected = entries[int(value) - 1]
            path = selected['disk'].resolve(strict=True)
        credentials = extract(path)
        target = save_session(credentials, args.output_dir.expanduser().resolve())
        credentials.clear()
        print(f'Saved login file: {target}')
        print('Keep this file private. It contains the account login. No values were printed or uploaded.')
        print('Provide the intended in-game Player ID separately; FPID is not that Player ID.')
        return 0
    except ExportError as exc:
        print(str(exc), file=sys.stderr)
    except (KeyboardInterrupt, EOFError):
        print('Cancelled. No login file exported.', file=sys.stderr)
    except Exception as exc:
        # A parser/library exception can contain XML or credentials. Never print its value or traceback.
        print(f'Export stopped ({type(exc).__name__}). Check Python dependencies, the selected disk, and that BlueStacks is closed.', file=sys.stderr)
    return 1


if __name__ == '__main__':
    raise SystemExit(main())
