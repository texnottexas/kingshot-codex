#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
trap 'read -r -p "Press Return to close." _unused' EXIT
if ! command -v python3 >/dev/null; then
  echo 'Install Python 3.11 or newer from python.org, then run this again.'
  exit 1
fi
python3 -c 'import sys; assert sys.version_info >= (3,11), "Python 3.11 or newer is required"'
python3 -m venv .venv
.venv/bin/python -m pip --disable-pip-version-check install -r requirements.txt
printf '%s\n' 'Log in to the intended Kingshot dummy account first, then stop its BlueStacks instance.'
.venv/bin/python export_session.py "$@"
