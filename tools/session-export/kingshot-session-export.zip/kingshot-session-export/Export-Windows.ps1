$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
try {
    if (Get-Command py -ErrorAction SilentlyContinue) {
        & py -3 -c 'import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)'
        if ($LASTEXITCODE -ne 0) { throw 'Install Python 3.11 or newer from python.org.' }
        & py -3 -m venv .venv
    } elseif (Get-Command python -ErrorAction SilentlyContinue) {
        & python -c 'import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)'
        if ($LASTEXITCODE -ne 0) { throw 'Install Python 3.11 or newer from python.org.' }
        & python -m venv .venv
    } else { throw 'Install Python 3.11 or newer from python.org, then run this again.' }
    if ($LASTEXITCODE -ne 0) { throw 'Could not create the local Python environment.' }
    & .\.venv\Scripts\python.exe -m pip --disable-pip-version-check install -r requirements.txt
    if ($LASTEXITCODE -ne 0) { throw 'Could not install the disk-reading libraries.' }
    Write-Host 'Log in to the intended Kingshot dummy account first, then stop all BlueStacks instances.'
    & .\.venv\Scripts\python.exe export_session.py @args
    if ($LASTEXITCODE -ne 0) { throw 'No login file exported. Read the message above.' }
} catch {
    Write-Host $_.Exception.Message
    exit 1
}
